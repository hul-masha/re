from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'onboarding/pwc_form.html'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    parent_template = None
    pass
    parent_template = environment.get_template('base.html', 'onboarding/pwc_form.html')
    for name, parent_block in parent_template.blocks.items():
        context.blocks.setdefault(name, []).append(parent_block)
    yield from parent_template.root_render_func(context)

def block_title(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass
    yield 'Change Password'

def block_header(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass
    yield 'Change Password'

def block_main(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_form = resolve('form')
    l_0_next = resolve('next')
    l_0_user = resolve('user')
    l_0_url = resolve('url')
    l_0_csrf_token = resolve('csrf_token')
    pass
    yield '\n    <article>\n        '
    if environment.getattr((undefined(name='form') if l_0_form is missing else l_0_form), 'errors'):
        pass
        yield '\n            <p>Errors during changing password: '
        yield to_string(environment.getattr((undefined(name='form') if l_0_form is missing else l_0_form), 'errors'))
        yield '</p>\n        '
    yield '\n\n        '
    if (undefined(name='next') if l_0_next is missing else l_0_next):
        pass
        yield '\n            '
        if environment.getattr((undefined(name='user') if l_0_user is missing else l_0_user), 'is_authenticated'):
            pass
            yield "\n                <p>Your account doesn't have access to this page. To proceed,\n                   please login with an account that has access.</p>\n            "
        else:
            pass
            yield '\n                <p>Please login to see this page.</p>\n            '
        yield '\n        '
    yield '\n    </article>\n\n    <article>\n        <form action="'
    yield to_string(context.call((undefined(name='url') if l_0_url is missing else l_0_url), 'onboarding:pwc'))
    yield '" method="post">\n            <input type="hidden" name="csrfmiddlewaretoken" value="'
    yield to_string((undefined(name='csrf_token') if l_0_csrf_token is missing else l_0_csrf_token))
    yield '">\n            '
    yield to_string(context.call(environment.getattr((undefined(name='form') if l_0_form is missing else l_0_form), 'as_p')))
    yield '\n            <button class="button" type="submit">Update</button>\n            <input name="next" type="hidden" value="'
    yield to_string((undefined(name='next') if l_0_next is missing else l_0_next))
    yield '">\n        </form>\n    </article>\n\n'

blocks = {'title': block_title, 'header': block_header, 'main': block_main}
debug_info = '1=12&3=17&5=25&7=33&9=45&10=48&13=51&14=54&24=62&25=64&26=66&28=68'