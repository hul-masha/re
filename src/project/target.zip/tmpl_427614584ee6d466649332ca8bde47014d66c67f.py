from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'index/index.html'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    parent_template = None
    pass
    parent_template = environment.get_template('base.html', 'index/index.html')
    for name, parent_block in parent_template.blocks.items():
        context.blocks.setdefault(name, []).append(parent_block)
    yield from parent_template.root_render_func(context)

def block_title(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_name = resolve('name')
    pass
    yield 'My page '
    yield escape((undefined(name='name') if l_0_name is missing else l_0_name))

def block_header(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass

def block_main(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_static = resolve('static')
    l_0_greeting = resolve('greeting')
    t_1 = environment.filters['safe']
    pass
    yield '\n<br><br>\n<br><br>\n        <aside>\n            <img alt="it\'s me" align="right" width="500" height="622" src="'
    yield escape(context.call((undefined(name='static') if l_0_static is missing else l_0_static), 'index/gBAs.jpg'))
    yield '">\n  <!img src="gBAs.jpg" align="right" width="500" height="622" alt="it\'s me">\n        </aside>\n    <article>\n        <br><br>\n\n<br><br>\n<br><br>\n<br><br>\n        <big>\n            '
    yield escape(t_1((undefined(name='greeting') if l_0_greeting is missing else l_0_greeting)))
    yield '\n      </big>\n    </article>\n<br><br>\n<br><br>\n<br><br>\n<br><br>\n'

blocks = {'title': block_title, 'header': block_header, 'main': block_main}
debug_info = '1=12&5=17&7=27&8=34&12=44&22=46'