from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'blog/comment.html'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    parent_template = None
    pass
    parent_template = environment.get_template('base.html', 'blog/comment.html')
    for name, parent_block in parent_template.blocks.items():
        context.blocks.setdefault(name, []).append(parent_block)
    yield from parent_template.root_render_func(context)

def block_title(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass
    yield 'My page comment'

def block_header(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass

def block_main(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_object = resolve('object')
    l_0_url = resolve('url')
    l_0_user = resolve('user')
    l_0_form = resolve('form')
    l_0_csrf_token = resolve('csrf_token')
    l_0_k = missing
    t_1 = environment.filters['length']
    pass
    yield '\n<br><br>\n<br><br>\n<br><br>\n'
    l_0_k = t_1(environment.getattr((undefined(name='object') if l_0_object is missing else l_0_object), 'print_parent'))
    yield '\n<h1><a href="'
    yield to_string(context.call((undefined(name='url') if l_0_url is missing else l_0_url), 'blog:post', kwargs={'pk': environment.getattr(environment.getattr((undefined(name='object') if l_0_object is missing else l_0_object), 'post'), 'pk')}))
    yield '">'
    yield to_string(environment.getattr(environment.getattr((undefined(name='object') if l_0_object is missing else l_0_object), 'post'), 'title'))
    yield '</a></h1>\n'
    if environment.getattr((undefined(name='user') if l_0_user is missing else l_0_user), 'is_authenticated'):
        pass
        yield '\n      <h2>You can answer to <a href="'
        yield to_string(context.call((undefined(name='url') if l_0_url is missing else l_0_url), 'blog:comments', kwargs={'pk': environment.getattr((undefined(name='object') if l_0_object is missing else l_0_object), 'pk')}))
        yield '">'
        yield to_string(environment.getattr((undefined(name='object') if l_0_object is missing else l_0_object), 'author'))
        yield ': '
        yield to_string(environment.getattr((undefined(name='object') if l_0_object is missing else l_0_object), 'message'))
        yield '</a></h2>\n<form action="'
        yield to_string(context.call((undefined(name='url') if l_0_url is missing else l_0_url), 'blog:for_comments', kwargs={'pk': environment.getattr((undefined(name='object') if l_0_object is missing else l_0_object), 'pk')}))
        yield '" method="post">\n                '
        yield to_string(context.call(environment.getattr((undefined(name='form') if l_0_form is missing else l_0_form), 'as_p')))
        yield '\n                <input type="hidden" name="csrfmiddlewaretoken" value="'
        yield to_string((undefined(name='csrf_token') if l_0_csrf_token is missing else l_0_csrf_token))
        yield '">\n                <button type="submit">Comment</button>\n            </form> <br>\n'
    yield '\n      '
    for l_1_obj in environment.getattr((undefined(name='object') if l_0_object is missing else l_0_object), 'print_parent')[::-1]:
        pass
        yield '\n      \n      <p> '
        yield to_string((' - ' * context.call(environment.getattr(environment.getattr((undefined(name='object') if l_0_object is missing else l_0_object), 'print_parent')[::-1], 'index'), l_1_obj)))
        yield to_string(environment.getattr(l_1_obj, 'author'))
        yield ': '
        yield to_string(environment.getattr(l_1_obj, 'message'))
        yield '\n        <a href="'
        yield to_string(context.call((undefined(name='url') if l_0_url is missing else l_0_url), 'blog:comments', kwargs={'pk': environment.getattr(l_1_obj, 'pk')}))
        yield '">Answers</a></p>\n         \n'
    l_1_obj = missing
    yield '\n'
    if (environment.getattr((undefined(name='object') if l_0_object is missing else l_0_object), 'print_first_childrens') == []):
        pass
        yield '\n   <p>'
        yield to_string((' - ' * ((undefined(name='k') if l_0_k is missing else l_0_k) + 1)))
        yield 'No one replied to this comment. You can be the first!</p>\n\n'
    else:
        pass
        yield '\n\n'
        for l_1_obj in context.call(environment.getattr((undefined(name='object') if l_0_object is missing else l_0_object), 'print_all_child')):
            pass
            yield '\n       <p>'
            yield to_string((' - ' * ((environment.getitem(l_1_obj, 0) + (undefined(name='k') if l_0_k is missing else l_0_k)) - 1)))
            yield to_string(environment.getattr(environment.getitem(l_1_obj, 1), 'author'))
            yield ': '
            yield to_string(environment.getattr(environment.getitem(l_1_obj, 1), 'message'))
            yield '\n\n       <a href="'
            yield to_string(context.call((undefined(name='url') if l_0_url is missing else l_0_url), 'blog:comments', kwargs={'pk': environment.getattr(environment.getitem(l_1_obj, 1), 'pk')}))
            yield '">Answers</a>\n       </p>\n'
        l_1_obj = missing
        yield '\n'
    yield '\n'
    if (not environment.getattr((undefined(name='user') if l_0_user is missing else l_0_user), 'is_authenticated')):
        pass
        yield '\n            <p><a href="'
        yield to_string(context.call((undefined(name='url') if l_0_url is missing else l_0_url), 'onboarding:index'))
        yield '">Sign in</a> to leave a comment.</p>\n    '
    yield '\n'

blocks = {'title': block_title, 'header': block_header, 'main': block_main}
debug_info = '1=12&2=17&4=25&5=32&9=46&10=48&11=52&12=55&13=61&14=63&15=65&19=68&21=71&22=76&29=80&30=83&35=88&36=91&38=96&42=101&43=104'