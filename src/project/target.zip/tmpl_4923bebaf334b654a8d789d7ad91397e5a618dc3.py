from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'onboarding/me_edit.html'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    parent_template = None
    pass
    parent_template = environment.get_template('base.html', 'onboarding/me_edit.html')
    for name, parent_block in parent_template.blocks.items():
        context.blocks.setdefault(name, []).append(parent_block)
    yield from parent_template.root_render_func(context)

def block_title(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass
    yield 'Edit Profile'

def block_header(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass

def block_main(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_user = resolve('user')
    l_0_csrf_token = resolve('csrf_token')
    l_0_form = resolve('form')
    pass
    yield '\n<br><br>\n<br><br><br><br>\n    <article>\n\n        '
    if environment.getattr((undefined(name='user') if l_0_user is missing else l_0_user), 'is_anonymous'):
        pass
        yield '\n\n            <h2>You are not authorized to use this</h2>\n\n        '
    else:
        pass
        yield '\n\n            <h2>Your new data</h2>\n\n            <form method="post">\n                <input type="hidden" name="csrfmiddlewaretoken" value="'
        yield to_string((undefined(name='csrf_token') if l_0_csrf_token is missing else l_0_csrf_token))
        yield '">\n                <div class="grid">\n                    '
        yield to_string(context.call(environment.getattr((undefined(name='form') if l_0_form is missing else l_0_form), 'as_p')))
        yield '\n                </div>\n                <button class="button" type="submit">Update</button>\n            </form>\n\n\n        '
    yield '\n\n    </article>\n\n'

blocks = {'title': block_title, 'header': block_header, 'main': block_main}
debug_info = '1=12&3=17&5=25&7=32&12=42&21=48&23=50'