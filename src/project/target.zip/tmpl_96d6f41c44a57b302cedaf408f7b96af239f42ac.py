from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'anon.html'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    parent_template = None
    pass
    parent_template = environment.get_template('base.html', 'anon.html')
    for name, parent_block in parent_template.blocks.items():
        context.blocks.setdefault(name, []).append(parent_block)
    yield from parent_template.root_render_func(context)

def block_title(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass
    yield 'Anonymous'

def block_header(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass

def block_main(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_user = resolve('user')
    l_0_url = resolve('url')
    pass
    yield '\n    '
    if (not environment.getattr((undefined(name='user') if l_0_user is missing else l_0_user), 'is_authenticated')):
        pass
        yield '\n        <article>\n            <h2>Actions</h2>\n            You are not authorized to see this content.\n            <section>\n                <ul>\n                    <li><a href="'
        yield to_string(context.call((undefined(name='url') if l_0_url is missing else l_0_url), 'onboarding:sign_in'))
        yield '">Sign In</a></li>\n                    <li><a href="'
        yield to_string(context.call((undefined(name='url') if l_0_url is missing else l_0_url), 'onboarding:sign_up'))
        yield '">Sign Up</a></li>\n                </ul>\n            </section>\n        </article>\n    '
    else:
        pass
        yield '\n        '
        yield from context.blocks['main_allowed'][0](context)
        yield '\n    '
    yield '\n'

def block_main_allowed(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass

blocks = {'title': block_title, 'header': block_header, 'main': block_main, 'main_allowed': block_main_allowed}
debug_info = '1=12&2=17&3=25&4=32&5=41&11=44&12=46&17=51'