from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'resume/index.html'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    parent_template = None
    pass
    parent_template = environment.get_template('base.html', 'resume/index.html')
    for name, parent_block in parent_template.blocks.items():
        context.blocks.setdefault(name, []).append(parent_block)
    yield from parent_template.root_render_func(context)

def block_title(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass
    yield 'My Resume'

def block_header(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass

def block_main(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_object_list = resolve('object_list')
    pass
    yield '\n\n   <br><br>\n<br><br>\n<br><br>\n<br><br>\n            <big>\n\t\t\t<p align=center>Knowledge and experience\n\t\t\t\t'
    for l_1_project in (undefined(name='object_list') if l_0_object_list is missing else l_0_object_list):
        pass
        yield '   \n\t\t\t\t<p align="center">'
        yield escape(environment.getattr(environment.getattr(l_1_project, 'firm'), 'name'))
        yield '</p>\n\t\t\t\t<p>from '
        yield escape(environment.getattr(l_1_project, 'started_at'))
        yield ' till '
        yield escape(environment.getattr(l_1_project, 'finished_at'))
        yield '</p>\n\t\t\t\t<p>'
        yield escape(environment.getattr(l_1_project, 'summary'))
        yield '</p>\n\t\t\t\t'
        if environment.getattr(l_1_project, 'achievemen'):
            pass
            yield '\n\t\t\t\t<p>Achievements: </p>\n\t\t\t\t<ul>\n\t\t\t\t\t'
            for l_2_ach in environment.getattr(l_1_project, 'achievemen'):
                pass
                yield '\n\t\t\t\t\t<li>'
                yield escape(l_2_ach)
                yield '</li>\n\t\t\t\t\t'
            l_2_ach = missing
            yield '\n\t\t\t\t</ul>\n\t\t\t\t'
        yield '\n\t\t\t\t'
        if environment.getattr(l_1_project, 'responsibil'):
            pass
            yield '\n\t\t\t\t<p>Responsibilities: </p>\n\t\t\t\t<ul>\n\t\t\t\t\t'
            for l_2_resp in environment.getattr(l_1_project, 'responsibil'):
                pass
                yield '\n\t\t\t\t\t<li>'
                yield escape(l_2_resp)
                yield '</li>\n\t\t\t\t\t'
            l_2_resp = missing
            yield '\n\t\t\t\t</ul>\n\t\t\t\t'
        yield '\n\t\t\t\t<p align="center">At '
        yield escape(environment.getattr(environment.getattr(l_1_project, 'firm'), 'name'))
        yield '</p>\n\t\t\t\t '
        if context.call(environment.getattr(environment.getattr(l_1_project, 'technologies'), 'count')):
            pass
            yield '\n\t\t\t\t<p align="center">Framework:</p>\n\t\t\t\t<ul>\n\t\t\t\t\t'
            for l_2_technology in context.call(environment.getattr(environment.getattr(l_1_project, 'technologies'), 'all')):
                pass
                yield '\n\t\t\t\t\t<li>'
                yield escape(environment.getattr(l_2_technology, 'name'))
                if environment.getattr(l_2_technology, 'version'):
                    pass
                    yield '\n\t\t\t\t\t\t'
                    yield escape(environment.getattr(l_2_technology, 'version'))
                    yield '</li>\n\t\t\t\t\t'
                yield '\n\t\t\t\t\t'
            l_2_technology = missing
            yield '\n\t\t\t\t</ul>\n                  '
        yield '\n\t\t\t\t'
    l_1_project = missing
    yield '\n\t\t\t\n            </big>\n\t\t\t<br><br>\n<br><br>\n<br><br>\n<br><br>\n<br><br>\n'

blocks = {'title': block_title, 'header': block_header, 'main': block_main}
debug_info = '1=12&5=17&8=25&10=32&18=40&19=43&20=45&21=49&22=51&25=54&26=57&30=62&33=65&34=68&38=73&39=75&42=78&43=81&44=85'