from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'resume/index.html'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    parent_template = None
    pass
    parent_template = environment.get_template('base.html', 'resume/index.html')
    for name, parent_block in parent_template.blocks.items():
        context.blocks.setdefault(name, []).append(parent_block)
    yield from parent_template.root_render_func(context)

def block_title(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass
    yield 'My Resume'

def block_header(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass

def block_main(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_projects = resolve('projects')
    pass
    yield '\n\n   <br><br>\n<br><br>\n<br><br>\n<br><br>\n            <big>\n\t\t\t<p align=center>Knowledge and experience\n\t\t\t\t'
    for l_1_project in (undefined(name='projects') if l_0_projects is missing else l_0_projects):
        pass
        yield '\n\t\t\t\t<p>from '
        yield escape(environment.getattr(l_1_project, 'started_at'))
        yield ' till '
        yield escape(environment.getattr(l_1_project, 'finished_at'))
        yield '</p>\n\t\t\t\t<p>'
        yield escape(environment.getattr(l_1_project, 'summary'))
        yield '</p>\n\t\t\t\t<p>Framework:</p>\n\t\t\t\t<ul>\n\t\t\t\t\t'
        for l_2_technology in context.call(environment.getattr(environment.getattr(l_1_project, 'technologies'), 'all')):
            pass
            yield '\n\t\t\t\t\t<li>'
            yield escape(environment.getattr(l_2_technology, 'name'))
            yield '</li>\n\t\t\t\t\t'
        l_2_technology = missing
        yield '\n\t\t\t\t</ul>\n\t\t\t\t'
    l_1_project = missing
    yield '\n\t\t\t\n            </big>\n\t\t\t<br><br>\n<br><br>\n<br><br>\n<br><br>\n<br><br>\n'

blocks = {'title': block_title, 'header': block_header, 'main': block_main}
debug_info = '1=12&5=17&8=25&10=32&18=40&19=43&20=47&23=49&24=52'