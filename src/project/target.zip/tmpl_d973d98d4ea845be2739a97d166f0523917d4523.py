from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'mail/txt/invitation.txt'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_service = resolve('service')
    l_0_link = resolve('link')
    pass
    yield 'Hi!\n\nTo complete your sign-up on '
    yield escape((undefined(name='service') if l_0_service is missing else l_0_service))
    yield ', please follow this link:\n\n'
    yield escape((undefined(name='link') if l_0_link is missing else l_0_link))
    yield '\n\nHope you will enjoy!'

blocks = {}
debug_info = '3=14&5=16'