from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'html/notification.html'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_recipient = resolve('recipient')
    l_0_reminder = resolve('reminder')
    pass
    yield '<!DOCTYPE html>\n<html lang="en">\n<head>\n    <meta charset="UTF-8">\n    <title>Reminder</title>\n</head>\n<body>\n<h3>Hi, '
    yield to_string(environment.getattr(environment.getattr((undefined(name='recipient') if l_0_recipient is missing else l_0_recipient), 'profile'), 'name'))
    yield '!</h3>\n<p>Here is a gentle reminder about the event:</p>\n<h1>'
    yield to_string(environment.getattr((undefined(name='reminder') if l_0_reminder is missing else l_0_reminder), 'title'))
    yield '</h1>\n<p>Location: '
    yield to_string(environment.getattr((undefined(name='reminder') if l_0_reminder is missing else l_0_reminder), 'location'))
    yield '</p>\n<p style="border: 1px darkgray dotted">'
    yield to_string(environment.getattr((undefined(name='reminder') if l_0_reminder is missing else l_0_reminder), 'description'))
    yield '</p>\n'
    if context.call(environment.getattr(environment.getattr((undefined(name='reminder') if l_0_reminder is missing else l_0_reminder), 'participants'), 'count')):
        pass
        yield '\n    <h3>Participants:</h3>\n    <ul>\n        '
        for l_1_party in context.call(environment.getattr(environment.getattr((undefined(name='reminder') if l_0_reminder is missing else l_0_reminder), 'participants'), 'all')):
            pass
            yield '\n            <li>'
            yield to_string(environment.getattr(environment.getattr(l_1_party, 'profile'), 'name'))
            yield ' <a href="mailto:'
            yield to_string(environment.getattr(l_1_party, 'email'))
            yield '">&lt;'
            yield to_string(environment.getattr(l_1_party, 'email'))
            yield '&gt;</a></li>\n        '
        l_1_party = missing
        yield '\n    </ul>\n'
    yield '\n</body>\n</html>'

blocks = {}
debug_info = '8=14&10=16&11=18&12=20&13=22&16=25&17=28'