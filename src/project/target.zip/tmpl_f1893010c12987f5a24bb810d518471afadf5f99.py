from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'blog/post.html'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    parent_template = None
    pass
    parent_template = environment.get_template('base.html', 'blog/post.html')
    for name, parent_block in parent_template.blocks.items():
        context.blocks.setdefault(name, []).append(parent_block)
    yield from parent_template.root_render_func(context)

def block_title(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass
    yield 'My page post'

def block_header(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass

def block_main(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_object = resolve('object')
    l_0_user = resolve('user')
    l_0_url = resolve('url')
    l_0_form = resolve('form')
    l_0_csrf_token = resolve('csrf_token')
    pass
    yield '\n<br><br>\n<br><br>\n<br><br>\n<h1>'
    yield to_string(environment.getattr((undefined(name='object') if l_0_object is missing else l_0_object), 'title'))
    yield '</h1>\n<p>'
    yield to_string(environment.getattr((undefined(name='object') if l_0_object is missing else l_0_object), 'content'))
    yield '</p>\n\n<article>\n        <h3>Comments</h3>\n        '
    if (not context.call(environment.getattr(environment.getattr((undefined(name='object') if l_0_object is missing else l_0_object), 'comments'), 'count'))):
        pass
        yield '\n            <p>No one commented this</p>\n        '
    yield '\n        '
    for l_1_comment in context.call(environment.getattr(environment.getattr((undefined(name='object') if l_0_object is missing else l_0_object), 'comments'), 'all')):
        pass
        yield '\n            <section>\n                '
        if (not environment.getattr(l_1_comment, 'have_parent')):
            pass
            yield '\n                <p><i>'
            yield to_string(environment.getattr(environment.getattr(environment.getattr(l_1_comment, 'author'), 'profile'), 'name'))
            yield ':-'
            yield to_string(environment.getattr(l_1_comment, 'message'))
            yield '      \n                <a href="'
            yield to_string(context.call((undefined(name='url') if l_0_url is missing else l_0_url), 'blog:comments', kwargs={'pk': environment.getattr(l_1_comment, 'pk')}))
            yield '">...</a></i></p>\n                '
        yield '\n            </section>\n        '
    l_1_comment = missing
    yield '\n        '
    if (not environment.getattr((undefined(name='user') if l_0_user is missing else l_0_user), 'is_authenticated')):
        pass
        yield '\n            <p><a href="'
        yield to_string(context.call((undefined(name='url') if l_0_url is missing else l_0_url), 'onboarding:index'))
        yield '">Sign in</a> to leave a comment.</p>\n        '
    else:
        pass
        yield '\n            <form action="'
        yield to_string(context.call((undefined(name='url') if l_0_url is missing else l_0_url), 'blog:comment', kwargs={'pk': environment.getattr((undefined(name='object') if l_0_object is missing else l_0_object), 'pk')}))
        yield '" method="post">\n                '
        yield to_string(context.call(environment.getattr((undefined(name='form') if l_0_form is missing else l_0_form), 'as_p')))
        yield '\n                <input type="hidden" name="csrfmiddlewaretoken" value="'
        yield to_string((undefined(name='csrf_token') if l_0_csrf_token is missing else l_0_csrf_token))
        yield '">\n                <button type="submit">Comment</button>\n            </form>\n        '
    yield '\n    </article>\n\n'

blocks = {'title': block_title, 'header': block_header, 'main': block_main}
debug_info = '1=12&2=17&4=25&5=32&9=44&10=46&14=48&17=52&19=55&20=58&21=62&25=67&26=70&28=75&29=77&30=79'