from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'txt/notification.txt'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_recipient = resolve('recipient')
    l_0_reminder = resolve('reminder')
    pass
    yield 'Hi '
    yield to_string(environment.getattr(environment.getattr((undefined(name='recipient') if l_0_recipient is missing else l_0_recipient), 'profile'), 'name'))
    yield '!\n\nHere is a gentle reminder about the event '
    yield to_string(environment.getattr((undefined(name='reminder') if l_0_reminder is missing else l_0_reminder), 'title'))
    yield '.\n\nLocation: '
    yield to_string(environment.getattr((undefined(name='reminder') if l_0_reminder is missing else l_0_reminder), 'location'))
    yield '\n\n---\n'
    yield to_string(environment.getattr((undefined(name='reminder') if l_0_reminder is missing else l_0_reminder), 'description'))
    yield '\n---\n\n'
    if context.call(environment.getattr(environment.getattr((undefined(name='reminder') if l_0_reminder is missing else l_0_reminder), 'participants'), 'count')):
        pass
        yield '\nParticipants:\n'
        for l_1_party in context.call(environment.getattr(environment.getattr((undefined(name='reminder') if l_0_reminder is missing else l_0_reminder), 'participants'), 'all')):
            pass
            yield '\n+ '
            yield to_string(environment.getattr(environment.getattr(l_1_party, 'profile'), 'name'))
            yield ' <'
            yield to_string(environment.getattr(l_1_party, 'email'))
            yield '>\n'
        l_1_party = missing
        yield '\n'

blocks = {}
debug_info = '1=14&3=16&5=18&8=20&11=22&13=25&14=28'