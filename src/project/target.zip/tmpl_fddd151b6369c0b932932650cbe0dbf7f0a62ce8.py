from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'base.html'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_static = resolve('static')
    l_0_request = resolve('request')
    l_0_url = resolve('url')
    l_0_File = resolve('File')
    l_0_user = resolve('user')
    l_0_file4 = resolve('file4')
    l_0_file5 = resolve('file5')
    l_0_file2 = resolve('file2')
    l_0_file3 = resolve('file3')
    l_0_ns = missing
    pass
    yield '<!DOCTYPE html>\n<html lang="en">\n<head>\n    <meta charset="UTF-8">\n    <title>'
    yield from context.blocks['title'][0](context)
    yield '</title>\n    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400" type="text/css">\n\t<link rel="stylesheet" href="'
    yield escape(context.call((undefined(name='static') if l_0_static is missing else l_0_static), 'css/font-awesome.min.css'))
    yield '" type="text/css">\n\t<link rel="stylesheet" href="'
    yield escape(context.call((undefined(name='static') if l_0_static is missing else l_0_static), 'css/bootstrap.min.css'))
    yield '" type="text/css">\n    <link rel="stylesheet" href="'
    yield escape(context.call((undefined(name='static') if l_0_static is missing else l_0_static), 'css/hero-slider-style.css'))
    yield '" type="text/css">\n    <link rel="stylesheet" href="'
    yield escape(context.call((undefined(name='static') if l_0_static is missing else l_0_static), 'css/magnific-popup.css'))
    yield '" type="text/css">\n    <link rel="stylesheet" href="'
    yield escape(context.call((undefined(name='static') if l_0_static is missing else l_0_static), 'css/tooplate-style.css'))
    yield '" type="text/css">\n    <link rel="shortcut icon" href="'
    yield escape(context.call((undefined(name='static') if l_0_static is missing else l_0_static), 'favicon.ico'))
    yield '" type="image/x-icon">\n</head>\n\n<body>\n\n        <div class="cd-hero">\n            <div class="cd-slider-nav">\n                <nav class="navbar navbar-fixed-top">\n                    <div class="tm-navbar-bg">\n'
    l_0_ns = environment.getattr(environment.getattr((undefined(name='request') if l_0_request is missing else l_0_request), 'resolver_match'), 'namespace')
    context.vars['ns'] = l_0_ns
    context.exported_vars.add('ns')
    yield '\n\n    <a href="'
    yield escape(context.call((undefined(name='url') if l_0_url is missing else l_0_url), environment.getitem((undefined(name='File') if l_0_File is missing else l_0_File), 2)))
    yield '" class="navbar-brand text-uppercase" href="#">\n    <i class="fa fa-home tm-brand-icon"></i>\n        '
    if environment.getattr((undefined(name='user') if l_0_user is missing else l_0_user), 'is_authenticated'):
        pass
        yield '\n        '
        yield escape(environment.getattr(environment.getattr((undefined(name='user') if l_0_user is missing else l_0_user), 'profile'), 'name'))
        yield '\n        '
    else:
        pass
        yield '\n        '
        yield escape(environment.getitem((undefined(name='File') if l_0_File is missing else l_0_File), 1))
        yield '\n    '
    yield '</a>\n                        <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#tmNavbar">\n                            <&#9776;>\n                        </button>\n                       <div class="collapse navbar-toggleable-md text-xs-center text-uppercase tm-navbar" id="tmNavbar">\n                            <ul class="nav navbar-nav">\n                                <li class="nav-item ">\n                                    <a href="'
    yield escape(context.call((undefined(name='url') if l_0_url is missing else l_0_url), environment.getitem((undefined(name='file4') if l_0_file4 is missing else l_0_file4), 0)))
    yield '" class="nav-link" href=""#0  data-no="1">'
    yield escape(environment.getitem((undefined(name='file4') if l_0_file4 is missing else l_0_file4), 1))
    yield '<span class="sr-only">(current)</span></a>\n                                </li>\n                                <li class="nav-item ">\n                                    <a href="'
    yield escape(context.call((undefined(name='url') if l_0_url is missing else l_0_url), environment.getitem((undefined(name='file5') if l_0_file5 is missing else l_0_file5), 0)))
    yield '" class="nav-link" href=""#0  data-no="2">'
    yield escape(environment.getitem((undefined(name='file5') if l_0_file5 is missing else l_0_file5), 1))
    yield '<span class="sr-only">(current)</span></a>\n                                </li>\n                                <li class="nav-item">\n                                    <a href="'
    yield escape(context.call((undefined(name='url') if l_0_url is missing else l_0_url), environment.getitem((undefined(name='file2') if l_0_file2 is missing else l_0_file2), 0)))
    yield '" class="nav-link" href="#0"  data-no="3">'
    yield escape(environment.getitem((undefined(name='file2') if l_0_file2 is missing else l_0_file2), 1))
    yield '</a>\n                                </li>\n                                <li class="nav-item ">\n                                    <a href="'
    yield escape(context.call((undefined(name='url') if l_0_url is missing else l_0_url), environment.getitem((undefined(name='file3') if l_0_file3 is missing else l_0_file3), 0)))
    yield '" class="nav-link" href=""#0  data-no="4">'
    yield escape(environment.getitem((undefined(name='file3') if l_0_file3 is missing else l_0_file3), 1))
    yield '<span class="sr-only">(current)</span></a>\n                                </li>\n\n\n                            </ul>\n                        </div>\n\n\n'
    yield from context.blocks['header'][0](context)
    yield '\n                    </div>\n                </nav>\n            </div>\n        </div>\n        '
    yield from context.blocks['main'][0](context)
    yield '\n    <footer>\n        <p align="center">\n            <a href="https://m.vk.com/id152533952">VK</a>\n        </p>\n        <p align="center">\n            <a href="mailto:masha.gul15@gmail.com">email</a>\n        </p>\n        <p align="center">(C) Gul Maria 2020</p>\n\n\n    </footer>\n</body>\n</html>'

def block_title(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass

def block_header(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass

def block_main(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass
    yield '\n'

blocks = {'title': block_title, 'header': block_header, 'main': block_main}
debug_info = '5=22&7=24&8=26&9=28&10=30&11=32&12=34&21=36&24=40&26=42&27=45&29=50&37=53&40=57&43=61&46=65&54=69&59=71&5=74&54=81&59=88'