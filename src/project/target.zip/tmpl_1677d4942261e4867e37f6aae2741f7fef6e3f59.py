from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'thoughts/index.html'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    parent_template = None
    pass
    parent_template = environment.get_template('base.html', 'thoughts/index.html')
    for name, parent_block in parent_template.blocks.items():
        context.blocks.setdefault(name, []).append(parent_block)
    yield from parent_template.root_render_func(context)

def block_title(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_number = resolve('number')
    pass
    yield to_string((undefined(name='number') if l_0_number is missing else l_0_number))
    yield ' Thoughts'

def block_header(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass

def block_main(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_message = resolve('message')
    t_1 = environment.filters['safe']
    pass
    yield '\n      <br><br>\n<br><br>\n<br><br>\n      <h1 align="center">Feedback</h1>\n      <br><br>\n      <br><br>\n      <form>\n          <p>\n              <label for="comment">Here you can leave recommendations and suggestions to the author website.</label>\n              <textarea id="comment" rows="4" cols="100" placeholder="'
    yield to_string(t_1((undefined(name='message') if l_0_message is missing else l_0_message)))
    yield '"></textarea>\n          </p>\n          <p>\n              <input type="submit" value="Sent">\n          </p>\n      </form>\n\n<br><br>\n<br><br>\n\n'

blocks = {'title': block_title, 'header': block_header, 'main': block_main}
debug_info = '1=12&5=17&7=27&8=34&18=43'