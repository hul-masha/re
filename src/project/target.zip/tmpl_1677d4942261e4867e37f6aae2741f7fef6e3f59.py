from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'thoughts/index.html'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    parent_template = None
    pass
    parent_template = environment.get_template('base.html', 'thoughts/index.html')
    for name, parent_block in parent_template.blocks.items():
        context.blocks.setdefault(name, []).append(parent_block)
    yield from parent_template.root_render_func(context)

def block_title(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass
    yield ' Thoughts'

def block_header(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass
    yield '\n'

def block_main(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_object_list = resolve('object_list')
    t_1 = environment.filters['length']
    pass
    yield '\n<br><br>\n<br><br>\n<br><br>\n'
    for l_1_p in (undefined(name='object_list') if l_0_object_list is missing else l_0_object_list):
        pass
        yield '\n\n    '
        if (t_1(l_1_p) == 1):
            pass
            yield '\n        <p>Post about '
            yield to_string(environment.getattr(environment.getitem(l_1_p, 0), 'tema'))
            yield '  text : '
            yield to_string(environment.getattr(environment.getitem(l_1_p, 0), 'post_text'))
            yield '</p>\n    '
        else:
            pass
            yield '\n            <p>'
            yield to_string(('-' * environment.getitem(l_1_p, 0)))
            yield to_string(environment.getattr(environment.getitem(l_1_p, 1), 'message'))
            yield '</p>\n'
        yield '\n'
    l_1_p = missing
    yield '\n\n      <h1 align="center">Feedback</h1>\n      <br><br>\n      <br><br>\n      <form>\n          <p>\n              <label for="comment">Here you can leave recommendations and suggestions to the author website.</label>\n              <textarea id="comment" rows="4" cols="100" placeholder="Write something..."></textarea>\n          </p>\n          <p>\n              <input type="submit" value="Sent">\n          </p>\n      </form>\n\n<br><br>\n<br><br>\n\n'

blocks = {'title': block_title, 'header': block_header, 'main': block_main}
debug_info = '1=12&5=17&7=25&9=33&13=42&15=45&16=48&18=55'