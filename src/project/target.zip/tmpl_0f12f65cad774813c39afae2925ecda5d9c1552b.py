from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'mail/html/invitation.html'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_service = resolve('service')
    l_0_link = resolve('link')
    pass
    yield '<!DOCTYPE html>\n<html lang="en">\n<head>\n    <meta charset="UTF-8">\n    <title>Sign-up</title>\n</head>\n<body>\n<h1>Hi!</h1>\n<p>To complete your sign-up on '
    yield to_string((undefined(name='service') if l_0_service is missing else l_0_service))
    yield ', please follow the link:</p>\n<p><a href="'
    yield to_string((undefined(name='link') if l_0_link is missing else l_0_link))
    yield '">'
    yield to_string((undefined(name='link') if l_0_link is missing else l_0_link))
    yield '</a></p>\n<p>Hope you will enjoy!</p>\n</body>\n</html>'

blocks = {}
debug_info = '9=14&10=16'