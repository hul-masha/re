from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'onboarding/me.html'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    parent_template = None
    pass
    parent_template = environment.get_template('anon.html', 'onboarding/me.html')
    for name, parent_block in parent_template.blocks.items():
        context.blocks.setdefault(name, []).append(parent_block)
    yield from parent_template.root_render_func(context)

def block_title(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass
    yield 'Profile'

def block_header(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass

def block_main_allowed(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_newbie_alert = resolve('newbie_alert')
    l_0_user = resolve('user')
    l_0_profile = resolve('profile')
    l_0_url = resolve('url')
    pass
    yield "\n<br><br>\n<br><br><br><br>\n    <article>\n\n        <h2>It's you!</h2>\n\n        "
    if (undefined(name='newbie_alert') if l_0_newbie_alert is missing else l_0_newbie_alert):
        pass
        yield '\n            <p><strong>'
        yield escape((undefined(name='newbie_alert') if l_0_newbie_alert is missing else l_0_newbie_alert))
        yield '</strong></p>\n        '
    yield '\n\n        <div class="grid">\n            <p class="header">Login name:</p>\n            <p>'
    yield escape(environment.getattr((undefined(name='user') if l_0_user is missing else l_0_user), 'username'))
    yield '</p>\n            <p>If this is your first time on our site\n                and you didn\'t change your login name yet, your login name and password are the same</p>\n            \n\n            <p class="header">E-mail:</p>\n            <p>'
    yield escape(environment.getattr((undefined(name='user') if l_0_user is missing else l_0_user), 'email'))
    yield '</p>\n\n            <p class="header">Display name:</p>\n            <p>'
    yield escape(environment.getattr((undefined(name='profile') if l_0_profile is missing else l_0_profile), 'name'))
    yield '</p>\n\n        </div>\n\n        <p>\n            <a href="'
    yield escape(context.call((undefined(name='url') if l_0_url is missing else l_0_url), 'onboarding:me_edit'))
    yield '">\n                <button class="button">Edit profile </button>\n            </a>or\n        <a href="'
    yield escape(context.call((undefined(name='url') if l_0_url is missing else l_0_url), 'onboarding:pwc'))
    yield '">\n            <button class="button" type="submit"> Go to Change Password</button></a>\n        </p>\n        <p>If you log out of your profile, click here:\n        <a href="'
    yield escape(context.call((undefined(name='url') if l_0_url is missing else l_0_url), 'onboarding:sign_out'))
    yield '">\n            <button class="button" type="submit">Sign out</button></a>\n        </a>\n                </p>\n    </article>\n\n'

blocks = {'title': block_title, 'header': block_header, 'main_allowed': block_main_allowed}
debug_info = '1=12&3=17&5=25&7=32&14=43&15=46&20=49&27=51&30=53&35=55&38=57&42=59'