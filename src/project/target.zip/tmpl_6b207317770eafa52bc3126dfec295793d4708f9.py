from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'blog/blog.html'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    parent_template = None
    pass
    parent_template = environment.get_template('base.html', 'blog/blog.html')
    for name, parent_block in parent_template.blocks.items():
        context.blocks.setdefault(name, []).append(parent_block)
    yield from parent_template.root_render_func(context)

def block_title(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass
    yield 'My page blog'

def block_header(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass

def block_main(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_object_list = resolve('object_list')
    t_1 = environment.filters['truncate']
    pass
    yield '\n<br><br>\n<br><br><br><br>\n'
    for l_1_post in (undefined(name='object_list') if l_0_object_list is missing else l_0_object_list):
        pass
        yield '\n        <article>\n            <h3>'
        yield escape(environment.getattr(l_1_post, 'title'))
        yield '</h3>\n            <p>'
        yield escape(t_1(environment, (environment.getattr(l_1_post, 'content') or ''), 200, end=''))
        yield ' <a href="'
        yield escape(context.call(environment.getattr(l_1_post, 'get_absolute_url')))
        yield '">...</a></p>\n        </article>\n    '
    l_1_post = missing
    yield '\n\n'

blocks = {'title': block_title, 'header': block_header, 'main': block_main}
debug_info = '1=12&2=17&4=25&5=32&8=41&10=44&11=46'