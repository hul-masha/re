from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'onboarding/pwc_done.html'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    parent_template = None
    pass
    parent_template = environment.get_template('base.html', 'onboarding/pwc_done.html')
    for name, parent_block in parent_template.blocks.items():
        context.blocks.setdefault(name, []).append(parent_block)
    yield from parent_template.root_render_func(context)

def block_title(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass
    yield 'Password Changed'

def block_header(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass

def block_main(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_url = resolve('url')
    pass
    yield '\n<br><br>\n<br><br><br><br>\n    <p>Password just has been successfully changed.</p>\n    <p><a href="'
    yield to_string(context.call((undefined(name='url') if l_0_url is missing else l_0_url), 'onboarding:sign_out'))
    yield '">Re-enter and check</a></p>\n    <p><a href="'
    yield to_string(context.call((undefined(name='url') if l_0_url is missing else l_0_url), 'onboarding:index'))
    yield '">Go back</a></p>\n\n'

blocks = {'title': block_title, 'header': block_header, 'main': block_main}
debug_info = '1=12&3=17&5=25&7=32&11=40&12=42'